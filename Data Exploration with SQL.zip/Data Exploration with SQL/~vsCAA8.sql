SELECT*
FROM [dbo].[Coviddeaths$]

--select*
--from [dbo].[CovidVaccinations$]

SELECT location,date,total_cases,new_cases,total_deaths,population
FROM [dbo].[Coviddeaths$]
where continent is not null
order by 1,2

--Looking at Total Cases vs Total Deaths
--Shows likelihood of dying if you contract covid

SELECT location,date,total_cases,total_deaths, (CONVERT(float, total_deaths) / NULLIF(CONVERT(float, total_cases), 0))*100 as DeathPercentage
FROM [dbo].[Coviddeaths$]
where location like '%kenya%'
order by 1,2

--Looking at the total cases vs population
--shows what percentage of population got covid

SELECT location,date,total_cases,population, (CONVERT(float, total_cases) / NULLIF(CONVERT(float, population), 0))*100 as InfectionPercentage
FROM [dbo].[Coviddeaths$]
where location like '%kenya%'
order by 1,2

--Looking at countries with highest infection rate compared to population

SELECT location, population, MAX(total_cases) as HighestInfectionCount,Max((CONVERT(float, total_deaths) / NULLIF(CONVERT(float, population), 0)))*100 as PercentagePopulationInfected
FROM [dbo].[Coviddeaths$]
--where location like '%kenya%'
Group by location, population
order by PercentagePopulationInfected

--showing countries with highest death count per population

SELECT location, MAX((CONVERT(float, total_deaths))) as TotalDeathCount
FROM [dbo].[Coviddeaths$]
--where location like '%kenya%'
where continent is not null
Group by location
order by TotalDeathCount desc

--Breaking data down by continent

SELECT location, MAX((CONVERT(float, total_deaths))) as TotalDeathCount
FROM [dbo].[Coviddeaths$]
--where location like '%kenya%'
where continent is null
Group by location
order by TotalDeathCount desc

--showing global numbers

SELECT date,SUM(CONVERT(float,new_cases)) as new_cases, SUM(CONVERT(float,new_deaths)) as new_deaths --,total_deaths, (CONVERT(float, total_deaths) / NULLIF(CONVERT(float, total_cases), 0))*100 as DeathPercentage
FROM [dbo].[Coviddeaths$]
--where location like '%kenya%'
where continent is not null
Group by date
order by 1,2 desc


SELECT date,SUM(new_cases) as total_cases,	SUM(CAST(new_deaths as int)) as total_deaths, SUM(CAST(new_deaths as int))/NULLIF (SUM(new_cases),0)*100 as Death_percentage
FROM [dbo].[Coviddeaths$]
where continent is not null
Group by date
order by 1,2 desc

---to get the total cases
SELECT SUM(new_cases) as total_cases,	SUM(CAST(new_deaths as int)) as total_deaths, SUM(CAST(new_deaths as int))/NULLIF (SUM(new_cases),0)*100 as Death_percentage
FROM [dbo].[Coviddeaths$]
where continent is not null
--Group by date
order by 1,2 desc


---from the covidvaccinations table, a join of the two

select dea.continent, dea.location, dea.date, dea.population, vac.new_vaccinations
from[dbo].[Coviddeaths$] dea
Join[dbo].[CovidVaccinations$] vac
	on dea.location = vac.location
	and dea.date = vac.date
where dea.continent is not null
order by 2,3

select dea.continent, dea.location, dea.date, dea.population, vac.new_vaccinations
SUM(CONVERT(float, vac.new_vaccinations)) OVER(Partition by dea.location)
from[dbo].[Coviddeaths$] dea
Join[dbo].[CovidVaccinations$] vac
	on dea.location = vac.location
	and dea.date = vac.date
where dea.continent is not null
order by 2,3






