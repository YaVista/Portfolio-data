SELECT*
FROM dbo.country_vaccinations$	

SELECT vaccines,total_vaccinations,COUNT(vaccines),country
FROM dbo.country_vaccinations$
WHERE vaccines = 'Moderna, Oxford/AstraZeneca, Pfizer/BioNTech, Sputnik V'
GROUP BY vaccines, total_vaccinations, country


SELECT*
FROM dbo.country_vaccinations$	

SELECT vaccines,total_vaccinations,COUNT(vaccines),country
FROM dbo.country_vaccinations$
GROUP BY vaccines, total_vaccinations, country


SELECT*
FROM dbo.country_vaccinations$	

SELECT vaccines,total_vaccinations,COUNT(vaccines),country
FROM dbo.country_vaccinations$
WHERE country = 'kenya'
GROUP BY vaccines, total_vaccinations, country

SELECT*
FROM dbo.country_vaccinations$	

SELECT vaccines,total_vaccinations,COUNT(vaccines),country
FROM dbo.country_vaccinations$
GROUP BY vaccines, total_vaccinations, country
ORDER BY country



SELECT vaccines,daily_vaccinations, country

FROM dbo.country_vaccinations$

ORDER BY country






